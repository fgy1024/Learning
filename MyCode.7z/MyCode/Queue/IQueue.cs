﻿using System;

public interface IQueue<T>
{
	//增（入队）
	void Equeue(T t);
	//删(出队)
	T Dequeue();
	//元素个数
	int Count
	{
		get;
	}
	//队顶元素
	T Peek();
}
