﻿using System;

public class MyQueue<T>:IQueue<T>
{
	int _head;  
	int _tail;
	T[] _data;

	public MyQueue()
	{
		_tail = 0;
		_head = 0;
		_data = new T[1024];
	}

	

	public T Dequeue()
	{
		T t = Peek();
		_head++;
		return t;
	}

	public void Equeue(T t)
	{
		if (_tail >= _data.Length)
		{
			T[] newdata = new T[_data.Length * 2];
			for(int i = 0; i < _data.Length; i++)
			{
				newdata[i] = _data[i];

			}
			_data = newdata;
		}
		_data[_tail] = t;
		_tail++;
	}
	public T Peek()
	{
		if (IsEmpty())
		{
			throw new Exception("当前为空队列");
		}
		return _data[_head];
	}
	bool IsEmpty()
	{
		return Count == 0;
	}
	public int Count
	{
		get
		{
			return _tail - _head;
		}
	}

}
