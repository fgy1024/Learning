﻿using System;

public interface IMyDictionary<TKey,TValue>
{
	//增
	void Add(TKey _key, TValue _value);
	//删
	bool Remove(TKey _key);
	//改
	//查
	TValue this[TKey _key] { get;set; }
	//元素个数
	int Count { get; }
	//是否有此键
	bool ContainsKey(TKey _key);
}
