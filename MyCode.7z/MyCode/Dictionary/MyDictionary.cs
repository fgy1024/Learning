﻿using System;

public class MyDictionary<Tkey,TValue>:IMyDictionary<Tkey,TValue>
{
	Tkey[] keys;
	TValue[] values;
	int _current;
	public MyDictionary()
	{
		keys = new Tkey[1024];
		values = new TValue[1024];
		_current = 0;
	}
	public TValue this[Tkey _key] { 
		get
		{
			int index = GetIndexByKey(_key);
			if (index == -1)
			{
				throw new Exception("当前容器没有这个键");
			}
			else
			{
				return values[index];
			}
		}
		set
		{
			int index = GetIndexByKey(_key);
			if (index == -1)
			{
				Add(_key, value);
			}
			else
			{
				values[index] = value;
			}
		}
	}

	public  int Count
	{
		get
		{
			return _current;
		}
	}

	public void Add(Tkey _key, TValue _value)
	{
		if (_current >= keys.Length)
		{
			Tkey[] newkeys = new Tkey[keys.Length * 2];
			TValue[] newvalue = new TValue[values.Length * 2];
			for(int i = 0; i < keys.Length; i++)
			{
				newkeys[i] = keys[i];
				newvalue[i] = values[i];
			}
			keys = newkeys;
			values = newvalue;
		}
		keys[_current] = _key;
		values[_current] = _value;
		_current++;
	}
	int GetIndexByKey(Tkey _key)
	{
		for(int i = 0; i < keys.Length; i++)
		{
			if (keys[i].Equals(_key))
			{
				return i;
			}
		}
		return -1;
	}
	public bool ContainsKey(Tkey _key)
	{
		return GetIndexByKey(_key) != -1;
	}

	public bool Remove(Tkey _key)
	{
		if (_current == 0)
		{
			return false;
		}
		int index = GetIndexByKey(_key);
		if (index == -1)
		{
			return false;
		}
		for(int i = index; i < _current - 1; i++)
		{
			keys[i] = keys[i + 1];
			values[i] = values[i + 1];
		}
		_current--;
		return true;
	}
}
