﻿using System;

public class MyStack<T> :IMyStack<T>
{
	T[] _data;
	int _current;
	public MyStack()
	{
		_data = new T[1024];
		_current = 0;
	}
	public int Count 
	{
		get
		{
			return _current;
		}
	}
	public T Peek()
	{
		if (IsEmpty())
		{
			throw new Exception("当前栈为空栈");
		}
		T t = _data[_current - 1];
		return t;
	}
	bool IsEmpty()
	{
		return Count == 0;
	}
	public T Pop()
	{
		T t = Peek();
		_current--;
		return t;
	}
	public void Push(T t)
	{	
		if (_current >= _data.Length)
		{
			T[] newdata = new T[_data.Length * 2];
			for(int i = 0; i < _data.Length; i++)
			{
				newdata[i] = _data[i];
			}
			_data = newdata;
		}
		_data[_current] = t;
		_current++;
	}
}
