﻿using System;

public interface IMyStack<T> 
{
	//增（入栈）
	void Push(T t);
	//删（出栈）
	T Pop();
	//栈顶元素
	T Peek();
	//元素个数
	int Count { get; }
}
