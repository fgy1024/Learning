﻿using System;

public interface IMyList<T>
{
	//增
	void Add(T t);
	void Insert(int index, T t);
	//删
	void RemoveAt(int index);
	void Remove(T t);
	void RemoveAll(T t);
	//改
	//查
	T this[int index]
	{
		get;
		set;
	}
	//元素的个数
	int Count
	{
		get;
	}
}
