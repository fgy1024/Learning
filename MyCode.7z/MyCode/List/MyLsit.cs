﻿using System;

class MyLsit<T> : IMyList<T>
{
    T[] _data;
    int _current;
    public MyLsit()
    {
        _data = new T[1024];
    }
    public void Add(T t)
    {
        if (_current >= _data.Length)
        {
            T[] _newdata = new T[_data.Length * 2];
            for (int i = 0; i < _data.Length; i++)
            {
                _newdata[i] = _data[i];
            }
            _data = _newdata;
        }
        _data[_current] = t;
        _current++;
    }
    public void Insert(int index, T t)
    {
        if (_current >= _data.Length)
        {
            T[] _newdata = new T[_data.Length * 2];
            for(int i = 0; i < _data.Length; i++)
            {
                _newdata[i] = _data[i];
            }
            _data = _newdata;
        }
        if (index > _current || index < 0)
        {
            throw new Exception("当前插入值索引越界");
        }
        for(int i = _current; i > index; i--)
        {
            _data[i] = _data[i - 1];
        }
        _data[index] = t;
        _current++;
    }
    public void Remove(T t)
    {
        int _index = GetIndexByValue(t);
        if (_index != -1)
        {
            RemoveAt(_index);
        }
    }
    public int GetIndexByValue(T t)
    {
        for(int i = 0; i < _current; i++)
        {
            if (t.Equals(_data[i]))
            {
                return i;
            }
        }
        return -1;
    } 
    public void RemoveAll(T t)
    {
        int _index = GetIndexByValue(t);
        while (_index != -1)
        {
            RemoveAt(_index);
            _index = GetIndexByValue(t);
        }
    }

    public void RemoveAt(int index)
    {
        if(index >= _current)
        {
            throw new Exception("删除当前索引越界");
        }
        for(int i = index; i < _current - 1; i++)
        {
            _data[i] = _data[i + 1];
        }
        _current--;
    }
    public T this[int index] 
    {
        get
        {
            if (index >= _current)
            {
                throw new Exception("当前查找时索引越界");              
            }
            return _data[index];
        }
        set
        {
            if (index >= _current)
            {
                throw new Exception("当前修改时索引越界");
            }
            _data[index] = value;
        }
    }

    public int Count
    {
        get
        {
            return _current;
        }
    }
}
