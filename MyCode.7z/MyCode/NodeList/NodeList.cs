﻿using System;

public class NodeList<T> : INodeList<T>
{
	Node<T> _head;
	int _current;
	public NodeList()
	{
		_head = new Node<T>();
		_current = 0;
	}

	public void Add(T t)
	{
		Node<T> newnode = new Node<T>(t);
		Node<T> node = _head;
		while (node.Next != null)
		{
			node = node.Next;
		}
		node.Next = newnode;
		_current++;
	}

	public void Insert(int index, T t)
	{
		if (index > _current || index < 0)
		{
			throw new Exception("插入时索引越界");
		}
		Node<T> newnode = new Node<T>(t);
		if (index == 0)
		{
			Node<T> node = _head.Next;
			_head.Next = newnode;
			newnode.Next = node;
		}
		else
		{
			Node<T> fornode = GetNodeByIndex(index - 1);
			Node<T> node = fornode.Next;
			fornode.Next = newnode;
			newnode.Next = node;
		}
		_current++;

	}
	Node<T> GetNodeByIndex(int index)
	{
		if (index < 0 || index > _current)
		{
			throw new Exception("找节点的时候索引越界");
		}
		Node<T> node = _head.Next;
		for(int i = 0; i < index; i++)
		{
			node = node.Next;
		}
		return node;
	}

	public void Remove(T t)
	{
		int index = GetIndexByValue(t);
		if (index != -1)
		{
			RemoveAt(index);
		}

	}
	int GetIndexByValue(T t)
	{
		Node<T> node = _head.Next;
		for(int i = 0; i < _current; i++)
		{
			if (node.Value.Equals(t))
			{
				return i;
			}
			node = node.Next;
		}
		return -1;
	}
	public void RemoveAll(T t)
	{
		int index = GetIndexByValue(t);
		while (index != -1)
		{
			RemoveAt(index);
			index = GetIndexByValue(t);
		}
	}

	public void RemoveAt(int index)
	{
		if (index < 0 || index >= _current)
		{
			throw new Exception("删除时索引越界");
		}
		if (index == 0)
		{
			Node<T> afternode = _head.Next.Next;
			_head.Next = afternode;
		}
		else
		{
			Node<T> forenode = GetNodeByIndex(index - 1);
			Node<T> backnode = forenode.Next.Next;
			forenode.Next = backnode;
		}
		_current--;
	}
	public T this[int index] 
	{ 
		get
		{
			if (index >= _current || index < 0)
			{
				throw new Exception("查找元素时索引越界");
			}
			return GetNodeByIndex(index).Value;
		}
		set 
		{
			if (index >= _current || index < 0)
			{
				throw new Exception("修改元素时索引越界");
			}
			GetNodeByIndex(index).Value = value;
		}

	}

	public int Count
	{
		get
		{
			return _current;
		}
	}
}
