﻿using System;

public class Node<T>
{
	T _value;
	Node<T> _next;
	public Node()
	{
		_value = default(T);
		_next = null;
	}
	public Node(T t)
	{
		_value = t;
		_next = null;
	}
	public T Value
	{
		get
		{
			return _value;
		}
		set
		{
			_value = value;
		}
	}
	public Node<T> Next
	{
		get
		{
			return _next;
		}
		set
		{
			_next = value;
		}
	}
}
