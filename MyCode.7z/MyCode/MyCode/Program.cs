﻿using System;

namespace MyCode
{
    class Program
    {
        static void Main(string[] args)
        {
            //想了一下，还是保留吧+.-
            Console.WriteLine("Hello World!");
        }        
    }
    /// <summary>
    /// 懒汉
    /// </summary>
    public class LazySingleTon
    {
        private static LazySingleTon Instance;
        private LazySingleTon() { }
        public static LazySingleTon GetInstance()
        {
            if (Instance == null)
                Instance = new LazySingleTon();
            return Instance;
        }
    }
    /// <summary>
    /// 饿汉
    /// </summary>
    public class HuangrySingleTon
    {
        private static HuangrySingleTon Instance = new HuangrySingleTon();
        private HuangrySingleTon() { }
        public static HuangrySingleTon GetInstance()
        {
            return Instance;
        }
    }
    /// <summary>
    /// 静态内部类
    /// </summary>
    public class StaticSingleTon
    {
        private static class StaticInside
        {
            public static readonly StaticSingleTon Instance = new StaticSingleTon();
        } 
        private StaticSingleTon() { }
        public static StaticSingleTon GetInstance()
        {
            return StaticInside.Instance;
        }
    }
    /// <summary>
    /// 实现数据交换
    /// </summary>
    /// <typeparam name="T">可代表的各种类型</typeparam>
    public class Swap<T>
    {
        public static void SwapFunction(ref T t1,ref T t2)
        {
            T temp = t1;
            t1 = t2;
            t1 = temp;
        }
    }
    /// <summary>
    /// 冒泡排序
    /// </summary>
    public class BubbleSort
    {
        public void Sort(int[] arr)
        {
            bool flag = true;
            for (int i = 0; i < arr.Length&&flag; i++)
            {
                flag = false;
                for (int j = 0; j < arr.Length - 1 - i; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        Swap<int>.SwapFunction(ref arr[j], ref arr[j + 1]);
                        flag = true;
                    }
                }
            }
            foreach (int i in arr)
                Console.Write("{0,2}", i);
        }
    }
    /// <summary>
    /// 选择排序
    /// </summary>
    public class SelectSort
    {
        public void Sort(int[] arr)
        {
            int i, j, index;
            for (i = 0; i < arr.Length; i++)
            {
                index = i;
                for (j = i; j < arr.Length; j++)
                {
                    if (arr[index] > arr[j])
                        index = j;
                }
                Swap<int>.SwapFunction(ref arr[i], ref arr[index]);
            }
            foreach (int k in arr)
                Console.Write(k + " ");
        }
    }
    /// <summary>
    /// 插入排序
    /// </summary>
    public class InsertSort
    {
        public void Sort(int[] arr)
        {

            for (int i = 0; i < arr.Length; i++)
            {
                int temp = arr[i];
                int j = i - 1;
                while (j >= 0 && arr[j] >= temp)
                {
                    arr[j + 1] = arr[j];
                    j--;
                }
                arr[j + 1] = temp;
            }
            foreach (int i in arr)
                Console.Write(i + " ");
        }
    }
    /// <summary>
    /// 快速排序
    /// </summary>
    public class QuickSort
    {
        public int FindValue(int[] arr, int left, int right)
        {
            int i, tail = left;
            for (i = left + 1; i < right; i++)
            {
                if (arr[left] >= arr[i])
                {
                    Swap<int>.SwapFunction(ref arr[++tail], ref arr[i]);
                }
            }
            Swap<int>.SwapFunction(ref arr[tail], ref arr[left]);
            return tail;
        }
        public void Sort(int[] arr, int left, int right)
        {
            if (left >= right)
                return;
            int index = FindValue(arr, left, right);
            Sort(arr, left, index);
            Sort(arr, index + 1, right);
        }
    }
    /// <summary>
    /// 大顶堆排序
    /// </summary>
    public class HeapSort
    {
        public void Sort(int[] arr)
        {
            int i;
            for (i = arr.Length / 2 - 1; i >= 0; i--)
            {
                Heap_Adjust(arr, i, arr.Length);
            }
            for (i = arr.Length - 1; i > 0; i--)
            {
                Swap<int>.SwapFunction(ref arr[i], ref arr[0]);
                Heap_Adjust(arr, 0, i);
            }
        }
        public void Heap_Adjust(int[] arr, int start, int length)
        {
            int temp = arr[start];
            int j;
            for (j = 2 * start + 1; j < length; j *= 2)
            {
                if (j + 1 < length && arr[j] < arr[j + 1])
                    j++;
                if (temp > arr[j])
                    break;
                else
                {
                    arr[start] = arr[j];
                    start = j;
                }
            }
            arr[start] = temp;
        }
    }
    /// <summary>
    /// 二路归并排序
    /// </summary>
    public class MergeSort
    {
        public void Sort(int[] arr, int start, int end)
        {
            if (start >= end)
                return;
            int index = (start + end) / 2;
            Sort(arr, start, index);
            Sort(arr, index + 1, end);
            Merge(arr, start, end, index);
        }
        public void Merge(int[] arr, int start, int end, int index)
        {
            int[] brr = new int[end + 1];
            int i = 0;
            int left = start;
            int right = index + 1;
            while (left <= index && right <= end)
            {
                if (arr[left] >= arr[right])
                    brr[i++] = arr[right++];
                else
                    brr[i++] = arr[left++];
            }
            while (left <= index)
                brr[i++] = arr[left++];
            while (right <= end)
                brr[i++] = arr[right++];
            i = 0;
            for (int j = start; j <= end; j++)
            {
                arr[j] = brr[i++];
            }
        }
    }

}
